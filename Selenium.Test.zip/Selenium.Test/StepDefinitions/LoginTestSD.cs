﻿//using NUnit.Framework;
//using OpenQA.Selenium;
//using OpenQA.Selenium.Chrome;
//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using TechTalk.SpecFlow;

//namespace Selenium.Test
//{
//    [Binding]
//    public sealed class LoginTestSD
//    {
//        //BeforeAfterFeature set = new BeforeAfterFeature();        
        
//        //ExcelUtil util = new ExcelUtil();

//       // public object ConfigurationManager { get; private set; }


//        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef
//        [Given(@"I navigate to the url of the login page")]
   
//        public static void GivenINavigateToTheUrlOfTheLoginPage()
//        {
//            //Before();
//           // GetScreenShot.SaveScreenShot();
//            // PropertiesConfiguration.driver = new ChromeDriver();

//            //string url = ConfigurationSettings.AppSettings["url"].ToString();
//            //string browser = ConfigurationSettings.AppSettings["browser"].ToString();
//            // PropertiesConfiguration.driver.Navigate().GoToUrl("http://executeautomation.com/demosite/Login.html");
//            //PropertiesConfiguration.driver.Navigate().GoToUrl(url);
//            //  PropertiesConfiguration.driver.Navigate().GoToUrl(" http://executeautomation.com/demosite/index.html?UserName=&Password=&Login=Login");

//        }

//        [Given(@"I see the page is loaded")]
     
//        public static void GivenISeeThePageIsLoaded()
//        {
//            Assert.AreEqual("Execute Automation", PropertiesConfiguration.driver.Title);
//        }

      
//        [When(@"I enter username ,password and press login button")]
//        public static void WhenIEnterUsernameAndPassword()
//        {
//            PO_LoginPage page = new PO_LoginPage();
//            CustomSetMethods.waitForElement(page.btnLogin,10);
//            // ExcelUtil.PopulateInCollection(@"D:\SeleniumTestVisualStudio\DataSheet.xlsx");
//           // Thread.Sleep(4000);
            
//                PO_LandingPage landingPage = page.Login(ExcelUtil.ReadData(1, "username"), ExcelUtil.ReadData(1, "password"));

//           // throw new InvalidOperationException("Boom");


//            }


//        [Then(@"the details page is loaded")]
//        public static void ThenTheDetailsPageIsLoaded()
//        {
//            Assert.AreEqual("Execute Automation", PropertiesConfiguration.driver.Title);

//        }

       
       

//    }
//}
