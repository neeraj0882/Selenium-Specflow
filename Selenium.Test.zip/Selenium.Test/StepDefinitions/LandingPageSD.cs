﻿//using NUnit.Framework;
//using OpenQA.Selenium;
//using Selenium.Test.Utils;
//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Drawing.Imaging;
//using System.Linq;
//using System.Text;
//using TechTalk.SpecFlow;

//namespace Selenium.Test
//{
//    [Binding]
//    public sealed class LandingPageSD
//    {
//        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef
//        PO_LandingPage landingPage = new PO_LandingPage();
//        [Given(@"I am on the Landing Page")]
    
//        public  void GivenIAmOnTheLandingPage()
//        {
//            //ExcelUtil util = new ExcelUtil();
//            //ExcelUtil.PopulateInCollection(@"D:\SeleniumTestVisualStudio\DataSheet.xlsx");
//            Assert.AreEqual("Execute Automation",PropertiesConfiguration.driver.Title);

//        }

//        [Given(@"I select title as ""(.*)""")]
//        public  void GivenISelectTitleAs(string title)
//        {
//            landingPage.SelectTitle(ExcelUtil.ReadData(1,"title"));
//        }

//        [When(@"I enter Title as per datasheet")]
//        public  void WhenIEnterTitleAsPerDatasheet()
//        {
//            landingPage.EnterInitial(ExcelUtil.ReadData(1, "initial"));
//        }

//        [When(@"I enter firstName as per datasheet")]
//        public  void WhenIEnterFirstNameAsPerDatasheet()
//        {
//           landingPage.EnterFirstName(ExcelUtil.ReadData(1, "firstname"));
//            Image img = GetScreenShot.GetEntireScreenshot();
//            //img.SaveAsFile("c:/test.png", ImageFormat.Png);
//            img.Save(@"D:\SeleniumTestVisualStudio\test.jpeg", ImageFormat.Jpeg);
//        }

//        [When(@"I press save button")]
//        public  void WhenIPressSaveButton()
//        {
//            landingPage.ClickSave();
//        }

//        [Then(@"the value in the Initial box is what I selected earlier")]
//        public  void ThenTheValueInTheInitialBoxIsWhatISelectedEarlier()
//        {            
//            Assert.AreEqual("Mr.", CustomGetMethods.GetDropDownValue(landingPage.ddlTitle));

//        }
//        [Then(@"I get report")]
//        public void ThenIGetReport()
//        {
//            RunReport.GenerateReport();
//        }

//    }
//}
