﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace Selenium.Test.StepDefinitions
{
    [Binding]
    public sealed class Google
    {
        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef
        IWebDriver driver = PropertiesConfiguration.GetDriver();
        [Given(@"I open google landing page")]
        public void GivenIOpenGoogleLandingPage()
        {
            
            var title = driver.Title;
            
        }


        [Given(@"I enter search term")]
        public void GivenIEnterSearchTerm()
        {
            driver.FindElement(By.Id("lst-ib")).SendKeys("testing");
        }


        [When(@"I press search")]
        public void WhenIPressSearch()
        {
            driver.FindElement(By.Name("btnK")).Click();
        }

        [Then(@"the I get search results related to testing")]
        public void ThenTheIGetSearchResultsRelatedToTesting()
        {
            Console.WriteLine("Done"); 
        }


    }
}
