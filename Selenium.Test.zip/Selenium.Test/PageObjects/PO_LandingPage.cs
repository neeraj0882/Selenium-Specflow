﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{


    class  PO_LandingPage
    {

        public  PO_LandingPage()
        {
            PageFactory.InitElements(PropertiesConfiguration.driver, this);
        }

        [FindsBy(How = How.Id, Using = "TitleId")]
        public  IWebElement ddlTitle { get; set; }

        [FindsBy(How = How.Id, Using = "Initial")]
        public  IWebElement txtInitial { get; set; }

        [FindsBy(How = How.Id, Using = "FirstName")]
        public  IWebElement txtFirstName { get; set; }

        [FindsBy(How = How.Name, Using = "Save")]
        public  IWebElement btnSave { get; set; }


        public   void fillForm(string title, string initial , string firstname)
        {
            CustomSetMethods.EnterText(txtInitial,initial);

            CustomSetMethods.EnterText(txtFirstName, firstname);

            CustomSetMethods.SelectDropDown(ddlTitle, title);       

            CustomSetMethods.Click(btnSave);


        }
        
        public  void SelectTitle(string title)
        {
          //  GetScreenShot.GetScreen("Landing Page");

            CustomSetMethods.SelectDropDown(ddlTitle, title);

        }
        public  void EnterInitial(string initial)
        {
            CustomSetMethods.EnterText(txtInitial, initial);

        }

        public  void EnterFirstName(string firstName)
        {
            CustomSetMethods.EnterText(txtFirstName, firstName);

        }

        public  void ClickSave()
        {
            CustomSetMethods.Click(btnSave);

           // GetScreenShot.GetScreen("Landing Page after save");
        }

    }
}
