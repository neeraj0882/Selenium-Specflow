﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{
    class PO_TablePage
    {
        public PO_TablePage()
        {
            
            PageFactory.InitElements(PropertiesConfiguration.driver, this);
        }

       

        [FindsBy(How = How.ClassName , Using = "w3-table-all")]
        public IWebElement table { get; set; }


        [FindsBy(How = How.XPath, Using = ".//*[@id='post-4218']/div[2]/table[1]/tbody")]
        public IWebElement table2 { get; set; }


    }
    }

