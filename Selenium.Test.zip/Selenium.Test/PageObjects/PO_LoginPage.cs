﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{
    class PO_LoginPage
    {
        public PO_LoginPage()
        {
            
            PageFactory.InitElements(PropertiesConfiguration.driver, this);
        }

       

        [FindsBy(How = How.Name , Using = "UserName")]
        public IWebElement txtUserName { get; set; }

        [FindsBy(How = How.Name, Using = "Password")]
        public IWebElement txtPwd { get; set; }

        [FindsBy(How = How.Name, Using = "Login")]
        public IWebElement btnLogin { get; set; }

        public PO_LandingPage Login(string userName , string passWord)
        {
          
            //txtUserName.SendKeys(userName);
            CustomSetMethods.EnterText(txtUserName,userName);

            CustomSetMethods.EnterText(txtPwd, passWord);

            //CustomGetMethods.Click(btnLogin);

            //txtPwd.SendKeys(passWord);

            btnLogin.Submit();
            //GetScreenShot.GetScreen("Login Screen");


            return new PO_LandingPage();
        }
    }
}
