﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace Selenium.Test
{
    [Binding]
    public sealed class Hooks1
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        [BeforeScenario]
        public static void BeforeScenario()
        {
            Console.WriteLine("Before Scenario##########");
            //GetScreenShot.SaveScreenShot();
            
            //TODO: implement logic that has to run before executing each scenario
        }

        [AfterScenario]
        public static void AfterScenario()
        {
            Console.WriteLine("After Scenario##########");
            //TODO: implement logic that has to run after executing each scenario
        }
        
    }
}
