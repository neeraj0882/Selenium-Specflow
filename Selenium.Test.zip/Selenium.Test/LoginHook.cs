﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace Selenium.Test
{
    [Binding]

    public class Bindings
    {
        private static bool firstRunExplode = true;

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            Console.WriteLine("BeforeTestRun");
              if (firstRunExplode)
              {
                Console.WriteLine("BeforeTestRun");
               // firstRunExplode = false;
               // throw new InvalidOperationException("Boom");
            }
        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            Console.WriteLine("AfterTestRun");
        }

        [Then("Test")]
        public void Live()
        {
            Console.WriteLine("Doing the test.");
        }
    }
}
    

