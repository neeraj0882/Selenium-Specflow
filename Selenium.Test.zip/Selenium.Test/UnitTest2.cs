﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Selenium.Test.Utils;
using RemoteBrowserMobProxy;
using OpenQA.Selenium;

using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using OpenQA.Selenium.Chrome;

namespace Selenium.Test
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://relevantcodes.com/get-rowcolumn-of-an-object-in-a-webtable/");
            var webTiming = (Dictionary<string, object>)((IJavaScriptExecutor)driver)
                .ExecuteScript(@"var performance = window.performance || window.webkitPerformance || window.mozPerformance || window.msPerformance || {};
                                 var timings = performance.timing || {};
                                 return timings;");
           
            
            foreach (var pair in webTiming)
            {
                Console.WriteLine(pair.Key, pair.Value);
            }
        }
    }
}
