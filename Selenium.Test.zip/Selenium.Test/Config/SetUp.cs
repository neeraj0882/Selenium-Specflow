﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Chrome;
using System.Configuration;

namespace Selenium.Test
{
    [Binding]
    public class BeforeAfterFeature
    {
        [BeforeFeature]
        public static void Before()
        {
            Console.WriteLine("** [BeforeFeature]");
            var featureTitle = FeatureContext.Current.FeatureInfo.Title;

            //path = relativePath[0] + ConfigurationSettings.AppSettings["path"];

            string path = CreateRelativePath.GetPath();
            path = path + "\\TestData\\";
            //Console.WriteLine(path);
            //ExcelUtil.PopulateInCollection(path + featureTitle + ".xlsx");            
            //ExcelUtil.PopulateInCollection(@"D:\SeleniumTestVisualStudio\LoginTest1.xlsx");
            PropertiesConfiguration.driver = new ChromeDriver();
            PropertiesConfiguration.driver.Navigate().GoToUrl("https://www.google.com/");
            //GetScreenShot.SaveScreenShot();
        }

        [AfterFeature]
        public static void After()
        {
            Console.WriteLine("** [AfterFeature]");
            PropertiesConfiguration.driver.Quit();
        }
        
    }
}