﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;


namespace Selenium.Test
{
    class PropertiesConfiguration
    {
        public static IWebDriver driver {set; get;}

        public static IWebDriver GetDriver()
        {

            return driver;

        }
        

    }
}
