﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{
    class CustomGetMethods
    {
        public static string GetText(IWebElement element) 
        {

            return element.GetAttribute("value");
           
        }

        public static string GetAttributeValue(IWebElement element,string attribute)
        {
            return element.GetAttribute(attribute);
                
           
        }
        public static string GetDropDownValue(IWebElement element)
        {
           return new SelectElement(element).AllSelectedOptions.SingleOrDefault().Text;
           
        }
        


    }
}
