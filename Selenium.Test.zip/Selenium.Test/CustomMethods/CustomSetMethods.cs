﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{
    class CustomSetMethods
    {

        public static IWebElement waitForElement(IWebElement element , int maxSeconds)
        {
            return new WebDriverWait(PropertiesConfiguration.driver, TimeSpan.FromSeconds(maxSeconds))
                .Until(ExpectedConditions.ElementToBeClickable(element));
        }



        public static void EnterText(IWebElement element, string data) 
        {


            element.SendKeys(data);
            //if (property == "id")
            //{
            //    PropertiesConfiguration.driver.FindElement(By.Id(value)).SendKeys(data);
            //}
            //if (property == "name")
            //{
            //    PropertiesConfiguration.driver.FindElement(By.Name(value)).SendKeys(data);
            //}
        }

        public static void Click(IWebElement element)
        {

            element.Click();
           // if (property == "id")
            //{
            //    PropertiesConfiguration.driver.FindElement(By.Id(value)).Click();
            //}
            //if (property == "name")
            //{
             //   PropertiesConfiguration.driver.FindElement(By.Name(value)).Click();
            //}
        }
        public static void SelectDropDown(IWebElement element,string data)
        {
            new SelectElement(element).SelectByText(data);
            //if (property == "id")
            //{
              //  new SelectElement(PropertiesConfiguration.driver.FindElement(By.Id(value))).SelectByText(data);
            //}
            //if (property == "name")
            //{
              //  new SelectElement(PropertiesConfiguration.driver.FindElement(By.Name(value))).SelectByText(data);
            //}
        }
    }
}
