﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium;
//using System.Drawing;
//using System.Drawing.Imaging;
//using System.Threading;
//using OpenQA.Selenium.Support.UI;

//namespace Selenium.Test
//{
//    [TestClass]
//    public class UnitTest1
//    {
//        IWebDriver driver;
//        [TestMethod]
//        public void TestMethod1()

//        {
//            PropertiesConfiguration.driver = new ChromeDriver();

//            driver = PropertiesConfiguration.driver;

//            //driver.Navigate().GoToUrl("http://www.w3schools.com/html/html_tables.asp");
//            driver.Navigate().GoToUrl("http://relevantcodes.com/get-rowcolumn-of-an-object-in-a-webtable/");
//            //WaitForPageLoad(2);
//            driver.FindElement(By.XPath(".//*[@id='menu-item-4742']/a")).Click();
//            driver.FindElement(By.XPath(".//*[@id='text-15']/div/form/input[1]")).SendKeys("test");


//        }
//           public void WaitForPageLoad(int maxWaitTimeInSeconds)
//        {
//            string state = string.Empty;
//            try
//            {
//                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(maxWaitTimeInSeconds));

//                //Checks every 500 ms whether predicate returns true if returns exit otherwise keep trying till it returns ture


//                wait.Until(d => {
//                    try
//                    {
//                        state = ((IJavaScriptExecutor)driver).ExecuteScript(@"return document.readyState").ToString();
//                        Console.Write(state);
//                    }
//                    catch (InvalidOperationException)
//                    {
//                        //Ignore
//                    }
//                    catch (NoSuchWindowException)
//                    {
//                        //when popup is closed, switch to last windows
//                       // driver.SwitchTo().Window(driver.WindowHandles.Count);
//                    }
//                    //In IE7 there are chances we may get state as loaded instead of complete
//                    return (state.Equals("complete", StringComparison.InvariantCultureIgnoreCase) || state.Equals("loaded", StringComparison.InvariantCultureIgnoreCase));

//                });
//            }
//            catch (TimeoutException)
//            {
//                //sometimes Page remains in Interactive mode and never becomes Complete, then we can still try to access the controls 

//                if (!state.Equals("interactive", StringComparison.InvariantCultureIgnoreCase))
//                    throw;
//            }
//            catch (NullReferenceException)
//            {
//                //sometimes Page remains in Interactive mode and never becomes Complete, then we can still try to access the controls 

//                if (!state.Equals("interactive", StringComparison.InvariantCultureIgnoreCase))

//                    throw;
//            }
//            catch (WebDriverException)
//            {
//                if (driver.WindowHandles.Count == 1)
//                {
//                    driver.SwitchTo().Window(driver.WindowHandles[0]);
//                }

//                state = ((IJavaScriptExecutor)driver).ExecuteScript(@"return document.readyState").ToString();

//                if (!(state.Equals("complete", StringComparison.InvariantCultureIgnoreCase) || state.Equals("loaded", StringComparison.InvariantCultureIgnoreCase)))
//                    throw;
//            }
//        }
     


//    }
//    }

