﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test.Utils
{
    class RunReport
    {
        public static void GenerateReport()
        {
            try {
                var process = new System.Diagnostics.Process();
                var startInfo = new System.Diagnostics.ProcessStartInfo
                {
                    WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal,
                    FileName = "cmd.exe",
                    RedirectStandardInput = true,
                    UseShellExecute = false
                };

                process.StartInfo = startInfo;
                process.Start();

                string filepath = CreateRelativePath.GetPath() + "\\";
                string resultsFolder = filepath + "Results";
                string inputFolder = CreateRelativePath.GetPath();


                process.StandardInput.WriteLine("cd" + " " + filepath);
                //process.StandardInput.WriteLine("cd..");
                //process.StandardInput.WriteLine("cd..");
                //process.StandardInput.WriteLine("cd
                Console.WriteLine("ReportUnit "+"\""+inputFolder+"\""+ " "+  "\""+resultsFolder+"\"");

                process.StandardInput.WriteLine("ReportUnit " + "\"" + inputFolder + "\"" + " " + "\"" + resultsFolder + "\"");
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
        }
    }
}
