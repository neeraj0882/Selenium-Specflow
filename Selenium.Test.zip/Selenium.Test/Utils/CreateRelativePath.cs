﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selenium.Test
{
    class CreateRelativePath
    {

        public static string GetPath()
        {
            
            string path = System.Reflection.Assembly.GetExecutingAssembly().Location;
            
            string[] relativePath = path.Split(new string[] { "Selenium.Test" }, StringSplitOptions.None);

            path = relativePath[0]+"Selenium.Test\\Selenium.Test";

            return path;

        }
        
    }
}
